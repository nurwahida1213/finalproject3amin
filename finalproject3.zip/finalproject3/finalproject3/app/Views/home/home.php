<?= $this->extend('layout/template') ?>

<?= $this->section('content') ?>

<div class="p-5 mb-4 bg-light rounded-3">
    <div class="container py-5">
        <h1 class="display-5 fw-bold">Selamat Datang Apa yang anda butuhkan</h1>
        <!-- <p class="col-md-8 fs-4">di laman portal berita</p> -->
        <!-- <button class="btn btn-primary btn-sm" type="button">Read more</button> -->

    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-12 my-2 card">
            <div class="card-body">
                <h5 class="h5">Layanan Kita Menyediakan Berbagai Makanan Kucing Loo</h5>
                <p>Ada Dryfood, Weadfood, dan juga berbagai macam snack juga</p>
            </div>
        </div>
        <div class="col-md-12 my-2 card">
            <div class="card-body">
                <h5 class="h5">Disini Juga Menyediakan Layanan Lainnya Untuk Hewan Peliharaan Anda</h5>
                <p>Ada Perawatan grooming, Kesehatan dan yang lainnya</p>
            </div>
        </div>
        <div class="col-md-12 my-2 card">
            <div class="card-body">
                <h5 class="h5">Perlengkapan Hewan Peliharaan Juga Ada</h5>
                <p>Dimulai dari mainan dan aksesoris lainnya</p>
            </div>
        </div>
    </div>
</div>

<?= $this->endSection() ?>